﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MTMessenger.Shared;

namespace MTMessenger.Client
{
    public class ReactionItem : INotifyPropertyChanged
    {
        public string Emoji { get; set; } = string.Empty;
        public List<string> Users { get; set; } = new List<string>();

        public int Count => Users.Count;
        public string ToolTipText => string.Join(", ", Users);
        public Visibility CountVisibility => Count > 1 ? Visibility.Visible : Visibility.Collapsed;

        public void UpdateUI()
        {
            OnPropertyChanged(nameof(Count));
            OnPropertyChanged(nameof(ToolTipText));
            OnPropertyChanged(nameof(CountVisibility));
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string prop) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
    }

    public class ChatMessageModel : INotifyPropertyChanged
    {
        public Guid Id { get; set; }
        public string Sender { get; set; } = string.Empty;
        public string Text { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
        public bool IsMine { get; set; }

        public Guid? ReplyTargetId { get; set; }
        public string ReplySender { get; set; } = string.Empty;
        public string ReplyText { get; set; } = string.Empty;
        public bool HasReply => ReplyTargetId.HasValue;

        public ObservableCollection<ReactionItem> Reactions { get; } = new ObservableCollection<ReactionItem>();
        public bool HasReactions => Reactions.Count > 0;

        public void ToggleReaction(string emoji, string username)
        {
            var existing = Reactions.FirstOrDefault(r => r.Emoji == emoji);
            if (existing != null)
            {
                if (existing.Users.Contains(username))
                {
                    existing.Users.Remove(username);
                    if (existing.Users.Count == 0) Reactions.Remove(existing);
                    else existing.UpdateUI();
                }
                else
                {
                    existing.Users.Add(username);
                    existing.UpdateUI();
                }
            }
            else
            {
                var newReact = new ReactionItem { Emoji = emoji };
                newReact.Users.Add(username);
                Reactions.Add(newReact);
            }
            OnPropertyChanged(nameof(HasReactions));
        }

        public string FormattedTime => Timestamp.ToShortTimeString();
        public HorizontalAlignment Alignment => IsMine ? HorizontalAlignment.Right : HorizontalAlignment.Left;
        public string BackgroundColor => IsMine ? "#D9FDD3" : "#FFFFFF";
        public Thickness BubbleMargin => IsMine ? new Thickness(40, 4, 0, 4) : new Thickness(0, 4, 40, 4);
        public CornerRadius BubbleRadius => IsMine ? new CornerRadius(12, 12, 2, 12) : new CornerRadius(12, 12, 12, 2);

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string prop) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
    }

    public class ChatListItem : INotifyPropertyChanged
    {
        private int _unreadCount;
        private DateTime _lastActivity;
        private bool _isMuted;
        private bool _isPinned;
        private int _pinnedOrder;

        public string Name { get; set; } = string.Empty;
        public bool IsGlobal { get; set; } = false;

        public DateTime LastActivity { get => _lastActivity; set { if (_lastActivity != value) { _lastActivity = value; OnPropertyChanged(nameof(LastActivity)); } } }

        public int UnreadCount
        {
            get => _unreadCount;
            set { if (_unreadCount != value) { _unreadCount = value; OnPropertyChanged(nameof(UnreadCount)); OnPropertyChanged(nameof(UnreadVisibility)); } }
        }

        public bool IsMuted
        {
            get => _isMuted;
            set { if (_isMuted != value) { _isMuted = value; OnPropertyChanged(nameof(IsMuted)); OnPropertyChanged(nameof(BadgeColor)); OnPropertyChanged(nameof(MuteIconVisibility)); } }
        }
        public bool IsPinned
        {
            get => _isPinned;
            set { if (_isPinned != value) { _isPinned = value; OnPropertyChanged(nameof(IsPinned)); OnPropertyChanged(nameof(PinIconVisibility)); } }
        }

        public int PinnedOrder
        {
            get => _pinnedOrder;
            set { if (_pinnedOrder != value) { _pinnedOrder = value; OnPropertyChanged(nameof(PinnedOrder)); } }
        }
        public Visibility UnreadVisibility => UnreadCount > 0 ? Visibility.Visible : Visibility.Collapsed;
        public Visibility MuteIconVisibility => IsMuted ? Visibility.Visible : Visibility.Collapsed;
        public Visibility PinIconVisibility => IsPinned ? Visibility.Visible : Visibility.Collapsed;
        public string BadgeColor => IsMuted ? "#A0AAB5" : "#25D366";

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public partial class ChatWindow : Window
    {
        private bool _isLoggingOut = false;

        private TcpClient _tcpClient;
        private NetworkStream _stream;
        private string _username;
        private string _currentChat = "Общий чат";
        private string _lastNotificationSender = string.Empty;

        private ChatMessageModel? _replyingTo = null;

        private Dictionary<string, List<ChatMessageModel>> _chatHistories = new Dictionary<string, List<ChatMessageModel>>();

        private Dictionary<string, List<ChatMessageModel>> _pinnedMessages = new Dictionary<string, List<ChatMessageModel>>();
        private Dictionary<string, int> _pinnedIndices = new Dictionary<string, int>();

        private ObservableCollection<ChatMessageModel> _currentMessages = new ObservableCollection<ChatMessageModel>();
        private ObservableCollection<ChatListItem> _chatItems = new ObservableCollection<ChatListItem>();

        public ChatWindow(TcpClient tcpClient, string username)
        {
            InitializeComponent();
            _tcpClient = tcpClient;
            _username = username;
            _stream = _tcpClient.GetStream();

            MyUsernameText.Text = _username;
            OnlineCountText.Text = "Онлайн: 1";

            _chatHistories["Общий чат"] = new List<ChatMessageModel>();
            MessagesListBox.ItemsSource = _currentMessages;
            UsersListBox.ItemsSource = _chatItems;

            _chatItems.Add(new ChatListItem { Name = "Общий чат", IsGlobal = true, LastActivity = DateTime.Now });

            System.Windows.Data.CollectionViewSource.GetDefaultView(_chatItems).Filter = SearchFilter;

            Task.Run(() => ReceiveMessagesAsync());
        }

        private async Task ReceiveMessagesAsync()
        {
            try
            {
                using (var reader = new System.IO.StreamReader(_stream, Encoding.UTF8, true))
                {
                    while (true)
                    {
                        string? jsonMessage = await reader.ReadLineAsync();
                        if (jsonMessage == null) break;

                        MessagePacket? packet = JsonSerializer.Deserialize<MessagePacket>(jsonMessage);
                        if (packet != null)
                        {
                            Dispatcher.Invoke(() =>
                            {
                                string chatKey = packet.Recipient == "Global" ? "Общий чат" : (packet.Sender == _username ? packet.Recipient : packet.Sender);

                                switch (packet.Type)
                                {
                                    case PacketType.Message:

                                        if (packet.Text == "[CMD_CLEAR_CHAT]")
                                        {
                                            if (_chatHistories.ContainsKey(chatKey))
                                            {
                                                _chatHistories[chatKey].Clear();
                                                if (_currentChat == chatKey) _currentMessages.Clear();

                                                if (_pinnedMessages.ContainsKey(chatKey))
                                                {
                                                    _pinnedMessages.Remove(chatKey);
                                                    _pinnedIndices.Remove(chatKey);
                                                    if (_currentChat == chatKey) UpdatePinnedUI();
                                                }

                                                var targetChat = _chatItems.FirstOrDefault(c => c.Name == chatKey);
                                                if (targetChat != null) targetChat.UnreadCount = 0;
                                            }
                                            break;
                                        }

                                        if (!_chatHistories.ContainsKey(chatKey)) _chatHistories[chatKey] = new List<ChatMessageModel>();

                                        var newMsg = new ChatMessageModel { Id = packet.Id, Sender = packet.Sender, Text = packet.Text, Timestamp = packet.Timestamp, IsMine = packet.Sender == _username };

                                        if (packet.TargetId.HasValue)
                                        {
                                            var targetMsg = _chatHistories[chatKey].FirstOrDefault(m => m.Id == packet.TargetId.Value);
                                            if (targetMsg != null)
                                            {
                                                newMsg.ReplyTargetId = targetMsg.Id;
                                                newMsg.ReplySender = targetMsg.Sender;
                                                newMsg.ReplyText = targetMsg.Text;
                                            }
                                        }

                                        _chatHistories[chatKey].Add(newMsg);

                                        var chatItem = _chatItems.FirstOrDefault(c => c.Name == chatKey);
                                        if (chatItem != null)
                                        {
                                            chatItem.LastActivity = DateTime.Now;
                                            if (_currentChat != chatKey && packet.Sender != "Система") chatItem.UnreadCount++;
                                        }
                                        SortChatList();

                                        if (_currentChat == chatKey)
                                        {
                                            _currentMessages.Add(newMsg);
                                            MessagesListBox.ScrollIntoView(_currentMessages.Last());
                                        }
                                        else if (packet.Sender != "Система" && (chatItem == null || !chatItem.IsMuted))
                                        {
                                            ShowNotification($"Новое сообщение от {packet.Sender}", chatKey);
                                        }
                                        break;

                                    case PacketType.DeleteMessage:
                                        if (packet.TargetId == Guid.Empty && packet.Text == "CLEARCHAT")
                                        {
                                            if (_chatHistories.ContainsKey(chatKey))
                                            {
                                                _chatHistories[chatKey].Clear();
                                                if (_currentChat == chatKey) _currentMessages.Clear();

                                                if (_pinnedMessages.ContainsKey(chatKey))
                                                {
                                                    _pinnedMessages.Remove(chatKey);
                                                    _pinnedIndices.Remove(chatKey);
                                                    if (_currentChat == chatKey) UpdatePinnedUI();
                                                }

                                                var targetChat = _chatItems.FirstOrDefault(c => c.Name == chatKey);
                                                if (targetChat != null) targetChat.UnreadCount = 0;
                                            }
                                            break;
                                        }

                                        if (_chatHistories.ContainsKey(chatKey) && packet.TargetId.HasValue)
                                        {
                                            if (packet.Sender == _username) break;

                                            var msgToRemove = _chatHistories[chatKey].FirstOrDefault(m => m.Id == packet.TargetId.Value);
                                            if (msgToRemove != null)
                                            {
                                                _chatHistories[chatKey].Remove(msgToRemove);
                                                if (_currentChat == chatKey)
                                                {
                                                    _currentMessages.Remove(msgToRemove);
                                                }
                                                else
                                                {
                                                    var chatToUpdate = _chatItems.FirstOrDefault(c => c.Name == chatKey);
                                                    if (chatToUpdate != null && chatToUpdate.UnreadCount > 0) chatToUpdate.UnreadCount--;
                                                }

                                                if (_pinnedMessages.ContainsKey(chatKey))
                                                {
                                                    var pinnedToRemove = _pinnedMessages[chatKey].FirstOrDefault(p => p.Id == msgToRemove.Id);
                                                    if (pinnedToRemove != null)
                                                    {
                                                        _pinnedMessages[chatKey].Remove(pinnedToRemove);
                                                        if (_pinnedMessages[chatKey].Count == 0) _pinnedMessages.Remove(chatKey);
                                                        else _pinnedIndices[chatKey] = 0;
                                                        if (_currentChat == chatKey) UpdatePinnedUI();
                                                    }
                                                }
                                            }
                                        }
                                        break;

                                    case PacketType.PinMessage:
                                        if (packet.Text == "UNPIN")
                                        {
                                            if (_pinnedMessages.ContainsKey(chatKey))
                                            {
                                                if (packet.TargetId.HasValue && packet.TargetId.Value != Guid.Empty)
                                                {
                                                    var toRemove = _pinnedMessages[chatKey].FirstOrDefault(m => m.Id == packet.TargetId.Value);
                                                    if (toRemove != null) _pinnedMessages[chatKey].Remove(toRemove);
                                                }
                                                else
                                                {
                                                    _pinnedMessages[chatKey].Clear();
                                                }

                                                if (_pinnedMessages[chatKey].Count == 0)
                                                {
                                                    _pinnedMessages.Remove(chatKey);
                                                    _pinnedIndices.Remove(chatKey);
                                                }
                                                else
                                                {
                                                    _pinnedIndices[chatKey] = _pinnedMessages[chatKey].Count - 1;
                                                }
                                                if (_currentChat == chatKey) UpdatePinnedUI();
                                            }
                                        }
                                        else if (_chatHistories.ContainsKey(chatKey) && packet.TargetId.HasValue)
                                        {
                                            var pinnedMsg = _chatHistories[chatKey].FirstOrDefault(m => m.Id == packet.TargetId.Value);
                                            if (pinnedMsg != null)
                                            {
                                                if (!_pinnedMessages.ContainsKey(chatKey)) _pinnedMessages[chatKey] = new List<ChatMessageModel>();

                                                if (!_pinnedMessages[chatKey].Any(m => m.Id == pinnedMsg.Id))
                                                {
                                                    _pinnedMessages[chatKey].Add(pinnedMsg);
                                                }

                                                _pinnedMessages[chatKey] = _pinnedMessages[chatKey].OrderBy(m => m.Timestamp).ToList();

                                                _pinnedIndices[chatKey] = _pinnedMessages[chatKey].Count - 1;

                                                if (packet.Sender != "Система" && packet.Sender != _username)
                                                {
                                                    ShowNotification($"{packet.Sender} закрепил сообщение", chatKey);
                                                }
                                                if (_currentChat == chatKey) UpdatePinnedUI();
                                            }
                                        }
                                        break;

                                    case PacketType.Reaction:
                                        if (_chatHistories.ContainsKey(chatKey) && packet.TargetId.HasValue)
                                        {
                                            if (packet.Sender == _username) break;

                                            var reactMsg = _chatHistories[chatKey].FirstOrDefault(m => m.Id == packet.TargetId.Value);
                                            if (reactMsg != null)
                                            {
                                                bool isNewReaction = !reactMsg.Reactions.Any(r => r.Emoji == packet.Text && r.Users.Contains(packet.Sender));

                                                reactMsg.ToggleReaction(packet.Text, packet.Sender);

                                                if (reactMsg.IsMine && isNewReaction)
                                                {
                                                    var reactionChatItem = _chatItems.FirstOrDefault(c => c.Name == chatKey);

                                                    if (packet.Sender != "Система" && (reactionChatItem == null || !reactionChatItem.IsMuted))
                                                    {
                                                        ShowNotification($"{packet.Sender} отреагировал {packet.Text}", chatKey);
                                                    }

                                                    if (reactionChatItem != null)
                                                    {
                                                        reactionChatItem.LastActivity = DateTime.Now;
                                                        if (_currentChat != chatKey) reactionChatItem.UnreadCount++;
                                                    }
                                                    SortChatList();
                                                }
                                            }
                                        }
                                        break;

                                    case PacketType.UsersUpdate:
                                        var usersList = JsonSerializer.Deserialize<string[]>(packet.Text);
                                        if (usersList != null)
                                        {
                                            OnlineCountText.Text = $"Онлайн: {usersList.Length}";

                                            foreach (var user in usersList)
                                            {
                                                if (user != _username && !_chatItems.Any(c => c.Name == user))
                                                    _chatItems.Add(new ChatListItem { Name = user, LastActivity = DateTime.MinValue });
                                            }
                                            for (int i = _chatItems.Count - 1; i >= 0; i--)
                                            {
                                                if (!_chatItems[i].IsGlobal && !usersList.Contains(_chatItems[i].Name))
                                                    _chatItems.RemoveAt(i);
                                            }
                                            SortChatList();
                                        }
                                        break;
                                }
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (!_isLoggingOut)
                {
                    Dispatcher.Invoke(() => MessageBox.Show($"Потеряно соединение: {ex.Message}"));
                }
            }
        }

        private void UpdatePinnedUI()
        {
            if (_pinnedMessages.ContainsKey(_currentChat) && _pinnedMessages[_currentChat].Count > 0)
            {
                int index = _pinnedIndices.ContainsKey(_currentChat) ? _pinnedIndices[_currentChat] : 0;
                if (index >= _pinnedMessages[_currentChat].Count) index = 0;

                var currentPinned = _pinnedMessages[_currentChat][index];
                int totalPins = _pinnedMessages[_currentChat].Count;

                if (index == totalPins - 1)
                {
                    PinnedMessageTitle.Text = "Закрепленное сообщение";
                }
                else
                {
                    PinnedMessageTitle.Text = "Предыдущее сообщение";
                }

                PinnedMessageText.Text = currentPinned.Text;

                PinnedMessageBar.Visibility = Visibility.Visible;
            }
            else
            {
                PinnedMessageBar.Visibility = Visibility.Collapsed;
            }
        }

        // Новые переменные для отслеживания перетаскивания чатов (добавь в начало класса ChatWindow к остальным полям)
        private Point _dragStartPoint;
        private ChatListItem? _draggedItem = null;

        private void SortChatList()
        {
            // УМНАЯ СОРТИРОВКА TELEGRAM: 
            // 1. Сначала идут закрепленные (IsPinned == true), отсортированные по их PinnedOrder
            // 2. Ниже идут незакрепленные, отсортированные по времени последней активности (LastActivity)
            var sorted = _chatItems
                .OrderByDescending(c => c.IsPinned)
                .ThenBy(c => c.IsPinned ? c.PinnedOrder : 0)
                .ThenByDescending(c => !c.IsPinned ? c.LastActivity : DateTime.MinValue)
                .ThenBy(c => c.Name)
                .ToList();

            var currentSelected = UsersListBox.SelectedItem;
            for (int i = 0; i < sorted.Count; i++)
            {
                var item = sorted[i];
                var oldIndex = _chatItems.IndexOf(item);
                if (oldIndex != i) _chatItems.Move(oldIndex, i);
            }
            if (currentSelected != null && UsersListBox.SelectedItem != currentSelected) UsersListBox.SelectedItem = currentSelected;
        }

        // --- ОБРАБОТЧИКИ ДЛЯ КОНТЕКСТНОГО МЕНЮ И DRAG-AND-DROP ---

        private void MenuTogglePin_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem && menuItem.DataContext is ChatListItem chat)
            {
                chat.IsPinned = !chat.IsPinned;

                if (chat.IsPinned)
                {
                    // При закреплении отправляем чат в конец списка закрепленных
                    int maxOrder = _chatItems.Where(c => c.IsPinned).Select(c => c.PinnedOrder).DefaultIfEmpty(-1).Max();
                    chat.PinnedOrder = maxOrder + 1;
                }

                SortChatList();
            }
        }

        private void UsersListBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _dragStartPoint = e.GetPosition(null);

            // Проверяем, что потащили именно закрепленный элемент списка
            if (sender is ListBox listBox)
            {
                var element = e.OriginalSource as DependencyObject;
                while (element != null && element != listBox)
                {
                    if (element is ListBoxItem item && item.DataContext is ChatListItem chatItem && chatItem.IsPinned)
                    {
                        _draggedItem = chatItem;
                        break;
                    }
                    element = System.Windows.Media.VisualTreeHelper.GetParent(element);
                }
            }
        }

        private void UsersListBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && _draggedItem != null)
            {
                Point mousePos = e.GetPosition(null);
                Vector diff = _dragStartPoint - mousePos;

                // Если мышь сдвинулась достаточно далеко — запускаем Drag-and-Drop
                if (Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                    Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance)
                {
                    if (sender is ListBox listBox)
                    {
                        DragDrop.DoDragDrop(listBox, _draggedItem, DragDropEffects.Move);
                        _draggedItem = null; // Сброс
                    }
                }
            }
        }

        private void UsersListBox_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(typeof(ChatListItem)))
            {
                var droppedItem = e.Data.GetData(typeof(ChatListItem)) as ChatListItem;
                var listBox = sender as ListBox;

                if (droppedItem != null && droppedItem.IsPinned && listBox != null)
                {
                    var element = e.OriginalSource as DependencyObject;
                    ChatListItem? targetItem = null;

                    while (element != null && element != listBox)
                    {
                        if (element is ListBoxItem item && item.DataContext is ChatListItem chat)
                        {
                            targetItem = chat;
                            break;
                        }
                        element = System.Windows.Media.VisualTreeHelper.GetParent(element);
                    }

                    if (targetItem != null && targetItem.IsPinned && targetItem != droppedItem)
                    {
                        var pinnedChats = _chatItems.Where(c => c.IsPinned).OrderBy(c => c.PinnedOrder).ToList();

                        pinnedChats.Remove(droppedItem);
                        int targetIdx = pinnedChats.IndexOf(targetItem);
                        pinnedChats.Insert(targetIdx, droppedItem);
                        for (int i = 0; i < pinnedChats.Count; i++)
                        {
                            pinnedChats[i].PinnedOrder = i;
                        }

                        SortChatList();
                    }
                }
            }
            _draggedItem = null;
        }

        private void ClearReplyState()
        {
            _replyingTo = null;
            ReplyPreviewBar.Visibility = Visibility.Collapsed;
        }

        private void UsersListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (UsersListBox.SelectedItem is ChatListItem selectedItem)
            {
                if (_currentChat == selectedItem.Name && MessagesListBox.Items.Count > 0)
                {
                    selectedItem.UnreadCount = 0;
                    return;
                }
                _currentChat = selectedItem.Name;
                selectedItem.UnreadCount = 0;

                ClearReplyState();
                UpdatePinnedUI();

                _currentMessages.Clear();
                if (_chatHistories.ContainsKey(_currentChat))
                {
                    foreach (var msg in _chatHistories[_currentChat]) _currentMessages.Add(msg);
                    if (_currentMessages.Count > 0) MessagesListBox.ScrollIntoView(_currentMessages.Last());
                }
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(MessageTextBox.Text)) return;

            string recipient = _currentChat == "Общий чат" ? "Global" : _currentChat;
            Guid? targetId = _replyingTo?.Id;

            MessagePacket packet = new MessagePacket(PacketType.Message, _username, MessageTextBox.Text.Trim(), recipient, targetId);
            string jsonMessage = JsonSerializer.Serialize(packet);
            byte[] data = Encoding.UTF8.GetBytes(jsonMessage + "\n");

            _stream.Write(data, 0, data.Length);

            var chatItem = _chatItems.FirstOrDefault(c => c.Name == _currentChat);
            if (chatItem != null)
            {
                chatItem.LastActivity = DateTime.Now;
                SortChatList();
            }

            MessageTextBox.Clear();
            ClearReplyState();
            MessageTextBox.Focus();
        }

        private async void ShowNotification(string message, string senderKey)
        {
            _lastNotificationSender = senderKey;
            NotificationText.Text = message;
            NotificationBorder.Visibility = Visibility.Visible;

            var fadeIn = new System.Windows.Media.Animation.DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.3));
            NotificationBorder.BeginAnimation(UIElement.OpacityProperty, fadeIn);

            await Task.Delay(3000);

            var fadeOut = new System.Windows.Media.Animation.DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.3));
            fadeOut.Completed += (s, e) => NotificationBorder.Visibility = Visibility.Collapsed;
            NotificationBorder.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }

        private void NotificationBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!string.IsNullOrEmpty(_lastNotificationSender))
            {
                var targetChat = _chatItems.FirstOrDefault(c => c.Name == _lastNotificationSender);
                if (targetChat != null) UsersListBox.SelectedItem = targetChat;
                NotificationBorder.Visibility = Visibility.Collapsed;
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (_isLoggingOut) return;

            e.Cancel = true;

            Dispatcher.InvokeAsync(() =>
            {
                ExitDialog dialog = new ExitDialog(_username, _chatHistories);
                dialog.Owner = this;
                dialog.ShowDialog();

                if (dialog.IsConfirmed)
                {
                    _isLoggingOut = true;

                    _stream?.Close();
                    _tcpClient?.Close();

                    MainWindow loginWindow = new MainWindow();

                    loginWindow.UsernameBox.Text = _username;
                    loginWindow.Show();

                    this.Close();
                }
            });
        }

        private void PinnedMessageBar_Click(object sender, MouseButtonEventArgs e)
        {
            if (_pinnedMessages.ContainsKey(_currentChat) && _pinnedMessages[_currentChat].Count > 0)
            {
                int index = _pinnedIndices.ContainsKey(_currentChat) ? _pinnedIndices[_currentChat] : 0;
                var targetMsg = _pinnedMessages[_currentChat][index];

                var target = _currentMessages.FirstOrDefault(m => m.Id == targetMsg.Id);
                if (target != null) MessagesListBox.ScrollIntoView(target);

                if (_pinnedMessages[_currentChat].Count > 1)
                {
                    index--;
                    if (index < 0) index = _pinnedMessages[_currentChat].Count - 1;
                    _pinnedIndices[_currentChat] = index;
                    UpdatePinnedUI();
                }
            }
        }

        private void ReplyBlock_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is FrameworkElement element && element.DataContext is ChatMessageModel msg && msg.ReplyTargetId.HasValue)
            {
                var target = _currentMessages.FirstOrDefault(m => m.Id == msg.ReplyTargetId.Value);
                if (target != null) MessagesListBox.ScrollIntoView(target);
            }
        }

        private void CancelReply_Click(object sender, RoutedEventArgs e) => ClearReplyState();

        private void MenuCopy_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem && menuItem.DataContext is ChatMessageModel msg)
            {
                Clipboard.SetText(msg.Text);
                ShowNotification("Текст скопирован в буфер обмена", "");
            }
        }

        private void MenuReact_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement element && element.DataContext is ChatMessageModel msg && element.Tag is string reactionObj)
            {
                string recipient = _currentChat == "Общий чат" ? "Global" : _currentChat;
                MessagePacket packet = new MessagePacket(PacketType.Reaction, _username, reactionObj, recipient, msg.Id);
                byte[] data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(packet) + "\n");
                _stream.Write(data, 0, data.Length);

                msg.ToggleReaction(reactionObj, _username);

                DependencyObject obj = element;
                while (obj != null && !(obj is ContextMenu))
                {
                    obj = System.Windows.Media.VisualTreeHelper.GetParent(obj);
                }
                if (obj is ContextMenu menu) menu.IsOpen = false;
            }
        }

        private void MenuPin_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem && menuItem.DataContext is ChatMessageModel msg)
            {
                PinDialog dialog = new PinDialog(_currentChat, isUnpin: false);
                dialog.Owner = this;
                dialog.ShowDialog();

                if (dialog.IsConfirmed)
                {
                    if (!_pinnedMessages.ContainsKey(_currentChat)) _pinnedMessages[_currentChat] = new List<ChatMessageModel>();
                    if (!_pinnedMessages[_currentChat].Any(m => m.Id == msg.Id)) _pinnedMessages[_currentChat].Add(msg);

                    _pinnedMessages[_currentChat] = _pinnedMessages[_currentChat].OrderBy(m => m.Timestamp).ToList();

                    _pinnedIndices[_currentChat] = _pinnedMessages[_currentChat].Count - 1;
                    UpdatePinnedUI();

                    if (dialog.PinForEveryone)
                    {
                        string recipient = _currentChat == "Общий чат" ? "Global" : _currentChat;
                        MessagePacket packet = new MessagePacket(PacketType.PinMessage, _username, "", recipient, msg.Id);
                        byte[] data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(packet) + "\n");
                        _stream.Write(data, 0, data.Length);
                    }
                }
            }
        }

        private void Unpin_Click(object sender, RoutedEventArgs e)
        {
            if (!_pinnedMessages.ContainsKey(_currentChat) || _pinnedMessages[_currentChat].Count == 0) return;

            PinDialog dialog = new PinDialog(_currentChat, isUnpin: true);
            dialog.Owner = this;
            dialog.ShowDialog();

            if (dialog.IsConfirmed)
            {
                int index = _pinnedIndices.ContainsKey(_currentChat) ? _pinnedIndices[_currentChat] : 0;
                var msgToUnpin = _pinnedMessages[_currentChat][index];

                _pinnedMessages[_currentChat].Remove(msgToUnpin);

                if (_pinnedMessages[_currentChat].Count == 0)
                    _pinnedMessages.Remove(_currentChat);
                else
                    _pinnedIndices[_currentChat] = _pinnedMessages[_currentChat].Count - 1;

                UpdatePinnedUI();

                if (dialog.PinForEveryone)
                {
                    string recipient = _currentChat == "Общий чат" ? "Global" : _currentChat;
                    MessagePacket packet = new MessagePacket(PacketType.PinMessage, _username, "UNPIN", recipient, msgToUnpin.Id);
                    byte[] data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(packet) + "\n");
                    _stream.Write(data, 0, data.Length);
                }
            }
        }

        private void MenuDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem && menuItem.DataContext is ChatMessageModel msg)
            {
                DeleteDialog dialog = new DeleteDialog(_currentChat, msg.IsMine);
                dialog.Owner = this;
                dialog.ShowDialog();

                if (dialog.IsConfirmed)
                {
                    _chatHistories[_currentChat].Remove(msg);
                    _currentMessages.Remove(msg);

                    if (_pinnedMessages.ContainsKey(_currentChat))
                    {
                        var pinnedToRemove = _pinnedMessages[_currentChat].FirstOrDefault(p => p.Id == msg.Id);
                        if (pinnedToRemove != null)
                        {
                            _pinnedMessages[_currentChat].Remove(pinnedToRemove);
                            if (_pinnedMessages[_currentChat].Count == 0) _pinnedMessages.Remove(_currentChat);
                            else _pinnedIndices[_currentChat] = 0;
                            UpdatePinnedUI();
                        }
                    }

                    if (dialog.DeleteForEveryone)
                    {
                        string recipient = _currentChat == "Общий чат" ? "Global" : _currentChat;
                        MessagePacket deletePacket = new MessagePacket(PacketType.DeleteMessage, _username, "", recipient, msg.Id);
                        byte[] data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(deletePacket) + "\n");
                        _stream.Write(data, 0, data.Length);
                    }
                }
            }
        }

        private void MenuReply_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem && menuItem.DataContext is ChatMessageModel msg)
            {
                _replyingTo = msg;
                ReplyPreviewName.Text = msg.Sender;
                ReplyPreviewText.Text = msg.Text;
                ReplyPreviewBar.Visibility = Visibility.Visible;
                MessageTextBox.Focus();
            }
        }

        private void MenuMute_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem && menuItem.DataContext is ChatListItem chat)
            {
                chat.IsMuted = !chat.IsMuted; // Переключатель мута
            }
        }

        private void MenuClear_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem && menuItem.DataContext is ChatListItem chat)
            {
                ClearDialog dialog = new ClearDialog(chat.Name);
                dialog.Owner = this;
                dialog.ShowDialog();

                if (dialog.IsConfirmed)
                {
                    if (_chatHistories.ContainsKey(chat.Name)) _chatHistories[chat.Name].Clear();
                    if (_currentChat == chat.Name) _currentMessages.Clear();

                    if (_pinnedMessages.ContainsKey(chat.Name))
                    {
                        _pinnedMessages.Remove(chat.Name);
                        _pinnedIndices.Remove(chat.Name);
                        if (_currentChat == chat.Name) UpdatePinnedUI();
                    }

                    chat.UnreadCount = 0;

                    if (dialog.ClearForEveryone)
                    {
                        string recipient = chat.Name == "Общий чат" ? "Global" : chat.Name;

                        MessagePacket packet = new MessagePacket(PacketType.Message, _username, "[CMD_CLEAR_CHAT]", recipient, null);
                        byte[] data = System.Text.Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(packet) + "\n");
                        _stream.Write(data, 0, data.Length);
                    }
                }
            }
        }

        // --- ЛОГИКА ПОИСКА ---

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Прячем или показываем лупу с текстом "Поиск..."
            SearchPlaceholder.Visibility = string.IsNullOrWhiteSpace(SearchBox.Text) ? Visibility.Visible : Visibility.Collapsed;

            // Заставляем WPF заново отфильтровать список при каждом нажатии клавиши
            System.Windows.Data.CollectionViewSource.GetDefaultView(_chatItems).Refresh();
        }

        private bool SearchFilter(object item)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
                return true;

            var chat = item as ChatListItem;
            if (chat == null) return false;

            string query = SearchBox.Text.ToLower();

            if (chat.Name.ToLower().Contains(query))
                return true;

            if (_chatHistories.ContainsKey(chat.Name))
            {
                bool hasMatchingMessage = _chatHistories[chat.Name].Any(m => m.Text.ToLower().Contains(query));
                if (hasMatchingMessage)
                    return true;
            }

            return false;
        }
    }
    
}