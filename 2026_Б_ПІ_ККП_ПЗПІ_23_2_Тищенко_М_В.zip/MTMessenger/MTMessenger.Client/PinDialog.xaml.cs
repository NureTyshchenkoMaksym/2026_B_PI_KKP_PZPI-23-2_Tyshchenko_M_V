﻿using System.Windows;

namespace MTMessenger.Client
{
    public partial class PinDialog : Window
    {
        public bool IsConfirmed { get; private set; } = false;
        public bool PinForEveryone => PinForEveryoneCheck.IsChecked == true;

        public PinDialog(string recipientName, bool isUnpin = false)
        {
            InitializeComponent();

            if (isUnpin)
            {
                ActionBtn.Content = "Unpin";

                if (recipientName == "Общий чат")
                {
                    DialogTitle.Text = "Открепить сообщение в группе?";
                    PinForEveryoneCheck.Content = "Открепить для всех участников";
                }
                else
                {
                    DialogTitle.Text = "Открепить это сообщение?";
                    PinForEveryoneCheck.Content = $"Также открепить для {recipientName}";
                }
            }
            else
            {
                ActionBtn.Content = "Pin";

                if (recipientName == "Общий чат")
                {
                    DialogTitle.Text = "Закрепить сообщение в группе?";
                    PinForEveryoneCheck.Content = "Уведомить всех участников";
                }
                else
                {
                    DialogTitle.Text = "Закрепить это сообщение?";
                    PinForEveryoneCheck.Content = $"Также закрепить для {recipientName}";
                }
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) { Close(); }

        private void Pin_Click(object sender, RoutedEventArgs e)
        {
            IsConfirmed = true;
            Close();
        }
    }
}