﻿using System.Windows;

namespace MTMessenger.Client
{
    public partial class ClearDialog : Window
    {
        public bool IsConfirmed { get; private set; } = false;
        public bool ClearForEveryone => ClearForEveryoneCheck.IsChecked == true;

        public ClearDialog(string chatName)
        {
            InitializeComponent();

            if (chatName == "Общий чат")
            {
                ClearForEveryoneCheck.Visibility = Visibility.Collapsed;
            }
            else
            {
                ClearForEveryoneCheck.Content = $"Также очистить для {chatName}";
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) { Close(); }
        private void Clear_Click(object sender, RoutedEventArgs e) { IsConfirmed = true; Close(); }
    }
}