﻿using System.Windows;

namespace MTMessenger.Client
{
    public partial class DeleteDialog : Window
    {
        public bool IsConfirmed { get; private set; } = false;
        public bool DeleteForEveryone => DeleteForEveryoneCheck.IsChecked == true;

        public DeleteDialog(string recipientName, bool isMine)
        {
            InitializeComponent();

            if (isMine)
            {
                if (recipientName == "Общий чат")
                    DeleteForEveryoneCheck.Content = "Удалить для всех";
                else
                    DeleteForEveryoneCheck.Content = $"Также удалить для {recipientName}";
            }
            else
            {
                if (recipientName != "Общий чат")
                {
                    DeleteForEveryoneCheck.Content = $"Также удалить для {recipientName}";
                }
                else
                {
                    DeleteForEveryoneCheck.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) { Close(); }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            IsConfirmed = true;
            Close();
        }
    }
}