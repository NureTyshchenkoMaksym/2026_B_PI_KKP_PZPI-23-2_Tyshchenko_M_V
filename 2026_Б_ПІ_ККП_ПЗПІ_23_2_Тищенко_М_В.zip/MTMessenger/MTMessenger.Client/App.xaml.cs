﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace MTMessenger.Client
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
