﻿using System;
using System.Net.Sockets;
using System.Windows;

namespace MTMessenger.Client
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(UsernameBox.Text))
            {
                MessageBox.Show("Пожалуйста, введите имя пользователя.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                ConnectButton.IsEnabled = false;

                TcpClient tcpClient = new TcpClient();
                tcpClient.Connect(IpBox.Text, 8888);

                MTMessenger.Shared.MessagePacket connectPacket = new MTMessenger.Shared.MessagePacket(
                    MTMessenger.Shared.PacketType.Connect,
                    UsernameBox.Text,
                    "Подключение к серверу"
                );

                string jsonMessage = System.Text.Json.JsonSerializer.Serialize(connectPacket);

                byte[] data = System.Text.Encoding.UTF8.GetBytes(jsonMessage);

                tcpClient.GetStream().Write(data, 0, data.Length);

                ChatWindow chatWindow = new ChatWindow(tcpClient, UsernameBox.Text);
                chatWindow.Show();

                this.Close();

                //MessageBox.Show("Успешное подключение к серверу!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Сервер недоступен. Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                ConnectButton.IsEnabled = true;
            }
        }
    }
}