﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Diagnostics;

namespace MTMessenger.Client
{
    public partial class ExitDialog : Window
    {
        public bool IsConfirmed { get; private set; } = false;
        private string _username;
        private Dictionary<string, List<ChatMessageModel>> _chatHistories;
        private string _archiveFullPath = "";

        public ExitDialog(string username, Dictionary<string, List<ChatMessageModel>> chatHistories)
        {
            InitializeComponent();
            _username = username;
            _chatHistories = chatHistories;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) { Close(); }

        private async void Exit_Click(object sender, RoutedEventArgs e)
        {
            if (ArchiveCheck.IsChecked == true)
            {
                OptionsPanel.Visibility = Visibility.Collapsed;
                ProgressPanel.Visibility = Visibility.Visible;

                await CreateArchiveAsync();

                FinalButtonsPanel.Visibility = Visibility.Visible;

            }
            else
            {
                IsConfirmed = true;
                Close();
            }
        }

        private async Task CreateArchiveAsync()
        {
            try
            {
                string timeStr = DateTime.Now.ToString("dd.MM.yyyy_HH-mm-ss");
                string fileName = $"session_{_username}_{timeStr}.txt";

                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                _archiveFullPath = Path.Combine(desktopPath, fileName);

                int totalMessages = 0;
                foreach (var chat in _chatHistories.Values) totalMessages += chat.Count;

                ArchiveProgress.Maximum = totalMessages > 0 ? totalMessages : 1;
                int processed = 0;

                using (StreamWriter writer = new StreamWriter(_archiveFullPath, false, Encoding.UTF8))
                {
                    await writer.WriteLineAsync($"=== Архив MTMessenger ===");
                    await writer.WriteLineAsync($"Сессия пользователя: {_username}");
                    await writer.WriteLineAsync($"Дата создания: {DateTime.Now}\n");

                    foreach (var chat in _chatHistories)
                    {
                        await writer.WriteLineAsync($"\n--- ЧАТ: {chat.Key} ---");
                        if (chat.Value.Count == 0)
                        {
                            await writer.WriteLineAsync("(История пуста)");
                            continue;
                        }

                        foreach (var msg in chat.Value)
                        {
                            await writer.WriteLineAsync($"[{msg.FormattedTime}] {msg.Sender}: {msg.Text}");
                            processed++;
                            ArchiveProgress.Value = processed;
                            ProgressStatusText.Text = $"Архивация: {chat.Key} ({processed}/{totalMessages})";

                            if (totalMessages < 200) await Task.Delay(15);
                        }
                    }
                }

                ProgressStatusText.Text = "Успешно архивировано!";
                ProgressStatusText.Foreground = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#25D366"));
                FilePathText.Text = $"Сохранено:\n{_archiveFullPath}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при архивации: {ex.Message}");
            }
        }


        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(_archiveFullPath) && File.Exists(_archiveFullPath))
            {
                Process.Start("explorer.exe", $"/select,\"{_archiveFullPath}\"");
            }
        }

        private void Finish_Click(object sender, RoutedEventArgs e)
        {
            IsConfirmed = true;
            Close();
        }
    }
}