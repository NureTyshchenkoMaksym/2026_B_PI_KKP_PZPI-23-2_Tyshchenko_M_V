﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

namespace MTMessenger.Server
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "MTMessenger Server";

            Console.WriteLine("Инициализация сервера...");

            Server server = new Server(8888);

            server.Start();
        }
    }
}
