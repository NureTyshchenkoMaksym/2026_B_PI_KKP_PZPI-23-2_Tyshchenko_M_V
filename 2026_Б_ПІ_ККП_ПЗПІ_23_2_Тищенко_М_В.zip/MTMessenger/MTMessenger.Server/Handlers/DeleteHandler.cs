﻿using System.Text.Json;
using MTMessenger.Shared;

namespace MTMessenger.Server.Handlers
{
    public class DeleteHandler : IPacketHandler
    {
        private Server _server;

        public DeleteHandler(Server server)
        {
            _server = server;
        }

        public void Execute(MessagePacket packet, ClientConnection client)
        {
            string jsonMessage = JsonSerializer.Serialize(packet);

            if (packet.Recipient == "Global")
            {
                _server.BroadcastMessage(jsonMessage);
            }
            else
            {
                _server.SendPrivateMessage(packet.Sender, packet.Recipient, jsonMessage);
            }
        }
    }
}