﻿using System;
using MTMessenger.Shared;

namespace MTMessenger.Server.Handlers
{
    public class ConnectHandler : IPacketHandler
    {
        private Server _server;

        public ConnectHandler(Server server)
        {
            _server = server;
        }

        public void Execute(MessagePacket packet, ClientConnection client)
        {
            foreach (var existingClient in _server.Clients.Values)
            {
                if (existingClient.UserName.Equals(packet.Sender, StringComparison.OrdinalIgnoreCase) && existingClient.Id != client.Id)
                {
                    Console.WriteLine($"[ОТКАЗ] Попытка входа с занятым ником: {packet.Sender}");

                    MessagePacket errorPacket = new MessagePacket(PacketType.Error, "Система", "Это имя уже занято в чате. Выберите другое.");
                    string errorJson = System.Text.Json.JsonSerializer.Serialize(errorPacket);

                    byte[] data = System.Text.Encoding.UTF8.GetBytes(errorJson + "\n");
                    client.Stream.Write(data, 0, data.Length);

                    _server.DisconnectClient(client.Id);

                    return;
                }
            }

            client.UserName = packet.Sender;
            Console.WriteLine($"[ID: {client.Id}] Авторизован как: {client.UserName}");

            _server.BroadcastUsersList();

            MessagePacket sysMsg = new MessagePacket(PacketType.Message, "Система", $"Пользователь {client.UserName} присоединился к чату.");
            string sysJson = System.Text.Json.JsonSerializer.Serialize(sysMsg);
            _server.BroadcastMessage(sysJson);
        }
    }
}