﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MTMessenger.Shared;

namespace MTMessenger.Server.Handlers
{
    public interface IPacketHandler
    {
        void Execute(MessagePacket packet, ClientConnection client);
    }
}
