﻿using System;
using System.Text.Json;
using MTMessenger.Shared;

namespace MTMessenger.Server.Handlers
{
    public class MessageHandler : IPacketHandler
    {
        private Server _server;

        public MessageHandler(Server server)
        {
            _server = server;
        }

        public void Execute(MessagePacket packet, ClientConnection client)
        {
            Console.WriteLine($"[{packet.Timestamp.ToShortTimeString()}] {packet.Sender} -> {packet.Recipient}: {packet.Text}");

            string jsonMessage = JsonSerializer.Serialize(packet);

            if (packet.Recipient == "Global")
            {
                _server.BroadcastMessage(jsonMessage);
            }
            else
            {
                _server.SendPrivateMessage(packet.Sender, packet.Recipient, jsonMessage);
            }
        }
    }
}