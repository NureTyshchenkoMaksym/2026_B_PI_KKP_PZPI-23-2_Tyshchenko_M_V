﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using MTMessenger.Shared;
using MTMessenger.Server.Handlers;

namespace MTMessenger.Server
{
    public class Server
    {
        private TcpListener _listener;

        public Dictionary<Guid, ClientConnection> Clients { get; private set; }

        private Dictionary<PacketType, IPacketHandler> _handlers;

        public Server(int port)
        {
            _listener = new TcpListener(IPAddress.Any, port);
            Clients = new Dictionary<Guid, ClientConnection>();
            _handlers = new Dictionary<PacketType, IPacketHandler>();

            _handlers.Add(PacketType.Connect, new ConnectHandler(this));
            _handlers.Add(PacketType.Message, new MessageHandler(this));

            _handlers.Add(PacketType.DeleteMessage, new DeleteHandler(this));

            _handlers.Add(PacketType.PinMessage, new ActionHandler(this));
            _handlers.Add(PacketType.Reaction, new ActionHandler(this));
        }

        public void Start()
        {
            _listener.Start();
            Console.WriteLine("Сервер запущен. Ожидание подключений...");

            while (true)
            {
                TcpClient tcpClient = _listener.AcceptTcpClient();

                ClientConnection client = new ClientConnection(tcpClient);
                Clients.Add(client.Id, client);

                Console.WriteLine($"Новое подключение! Выделен ID: {client.Id}");

                Task.Run(() => ListenToClient(client));
            }
        }

        private void ListenToClient(ClientConnection client)
        {
            try
            {
                byte[] buffer = new byte[4096];

                while (true)
                {
                    int bytesRead = client.Stream.Read(buffer, 0, buffer.Length);

                    if (bytesRead == 0) break;

                    string jsonMessage = System.Text.Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    MessagePacket? packet = System.Text.Json.JsonSerializer.Deserialize<MessagePacket>(jsonMessage);

                    if (packet != null && _handlers.ContainsKey(packet.Type))
                    {
                        _handlers[packet.Type].Execute(packet, client);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка у клиента {client.Id}: {ex.Message}");
            }
            finally
            {
                DisconnectClient(client.Id);
            }
        }

        public void BroadcastMessage(string jsonMessage)
        {
            byte[] data = System.Text.Encoding.UTF8.GetBytes(jsonMessage + "\n");

            foreach (var client in Clients.Values)
            {
                try
                {
                    client.Stream.Write(data, 0, data.Length);
                }
                catch
                {
                    
                }
            }
        }

        public void SendPrivateMessage(string senderName, string recipientName, string jsonMessage)
        {
            byte[] data = System.Text.Encoding.UTF8.GetBytes(jsonMessage + "\n");

            foreach (var client in Clients.Values)
            {
                if (client.UserName == senderName || client.UserName == recipientName)
                {
                    try
                    {
                        client.Stream.Write(data, 0, data.Length);
                    }
                    catch
                    {
                    
                    }
                }
            }
        }

        public void BroadcastUsersList()
        {
            var userNames = new List<string>();
            foreach (var client in Clients.Values)
            {
                if (!string.IsNullOrEmpty(client.UserName))
                {
                    userNames.Add(client.UserName);
                }
            }

            string usersJson = System.Text.Json.JsonSerializer.Serialize(userNames);

            MessagePacket updatePacket = new MessagePacket(PacketType.UsersUpdate, "Server", usersJson);

            string packetJson = System.Text.Json.JsonSerializer.Serialize(updatePacket);
            BroadcastMessage(packetJson);
        }

        public void DisconnectClient(Guid clientId)
        {
            if (Clients.TryGetValue(clientId, out ClientConnection? client))
            {
                string disconnectedUser = client.UserName;

                client.Close();
                Clients.Remove(clientId);
                Console.WriteLine($"Клиент {clientId} отключен.");

                BroadcastUsersList();

                if (!string.IsNullOrEmpty(disconnectedUser))
                {
                    MessagePacket sysMsg = new MessagePacket(PacketType.Message, "Система", $"Пользователь {disconnectedUser} покинул чат.");
                    string sysJson = System.Text.Json.JsonSerializer.Serialize(sysMsg);
                    BroadcastMessage(sysJson);
                }
            }
        }
    }
}