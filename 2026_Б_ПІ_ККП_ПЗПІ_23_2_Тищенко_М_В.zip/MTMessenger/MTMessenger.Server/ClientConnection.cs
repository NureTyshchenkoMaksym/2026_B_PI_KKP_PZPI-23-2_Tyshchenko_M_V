﻿using System;
using System.Net.Sockets;

namespace MTMessenger.Server
{
    public class ClientConnection
    {
        public string UserName { get; set; } = string.Empty;
        public Guid Id { get; private set; }
        public NetworkStream Stream { get; private set; }

        private TcpClient _tcpClient;

        public ClientConnection(TcpClient tcpClient)
        {
            Id = Guid.NewGuid();
            _tcpClient = tcpClient;
            Stream = _tcpClient.GetStream();
        }

        public void Close()
        {
            Stream?.Close();
            _tcpClient?.Close();
        }
    }
}