﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTMessenger.Shared
{
    public enum PacketType
    {
        Connect,
        Message,
        UsersUpdate,
        Disconnect,
        Error,
        DeleteMessage,
        PinMessage,
        Reaction,
    }
}