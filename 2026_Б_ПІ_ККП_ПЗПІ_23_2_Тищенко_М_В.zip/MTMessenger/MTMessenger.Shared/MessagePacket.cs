﻿using System;

namespace MTMessenger.Shared
{
    public class MessagePacket
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public Guid? TargetId { get; set; }

        public PacketType Type { get; set; }
        public string Sender { get; set; } = string.Empty;
        public string Recipient { get; set; } = "Global";
        public string Text { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }

        public MessagePacket() { }

        public MessagePacket(PacketType type, string sender, string text, string recipient = "Global", Guid? targetId = null)
        {
            Type = type;
            Sender = sender;
            Text = text;
            Recipient = recipient;
            TargetId = targetId;
            Timestamp = DateTime.Now;
        }
    }
}